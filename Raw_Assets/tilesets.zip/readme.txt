You must credit Paul Barden for tiles included in this set, the original main tile author "Damian Gasinski aka Gassasin" which can be viewed here: https://opengameart.org/content/16xx16-tileset-pokemonzelda-styled

License is CC-BY 3.0